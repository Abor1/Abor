/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.UIutil;
/**
 *工具类
 * @author Abor
 */
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JFrame;
public class UIUtil {
    //设置图标
    public static void setIcon(JFrame jf){
        Toolkit toolkit=Toolkit.getDefaultToolkit();
        Image image=toolkit.getImage("src\\com\\resource\\bombFind.jpg");
        jf.setIconImage(image);
    }
    //窗体在屏幕居中
    public static void setFrameCenter(JFrame frame){
        Toolkit toolkit=Toolkit.getDefaultToolkit();
        Dimension dimensionScreen= toolkit.getScreenSize();
        double screenWidth=dimensionScreen.getWidth();
        double screenHeight=dimensionScreen.getHeight();
        int frameWidth=frame.getWidth();
        int frameHeight=frame.getHeight();
        
        int x=(int)(screenWidth-frameWidth)/2;
        int y=(int)(screenHeight-frameHeight)/2;
        frame.setLocation(x,y);
    }
}

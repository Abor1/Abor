/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.frame;

import javax.swing.JOptionPane;

import com.UIutil.UIUtil;

/**
 *
 * @author Abor
 */
public class firstFrame extends javax.swing.JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public firstFrame() {
		initComponents();
		init();
	}
	private void init() {
		this.setTitle("欢迎来到Abor制作的扫雷");
		UIUtil.setIcon(this);
		UIUtil.setFrameCenter(this);
	}
	private void initComponents() {

		jLabel1 = new javax.swing.JLabel();
		bombNumbers = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		gridNumbers = new javax.swing.JTextField();
		startGame = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setBackground(new java.awt.Color(153, 255, 255));

		jLabel1.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		jLabel1.setText("请输入雷数（5-15）：");

		jLabel2.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		jLabel2.setText("请输入行列数（5-15）：");
		
		bombNumbers.setFont(new java.awt.Font("宋体", 0, 20));
		gridNumbers.setFont(new java.awt.Font("宋体", 0, 20));
		
		startGame.setBackground(new java.awt.Color(255, 255, 255));
		startGame.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		startGame.setForeground(new java.awt.Color(255, 0, 51));
		startGame.setText("开始游戏");
		startGame.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				startGameActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(layout.createSequentialGroup().addGap(88, 88, 88)
										.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(jLabel1).addComponent(jLabel2))
										.addGap(51, 51, 51)
										.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(gridNumbers, javax.swing.GroupLayout.PREFERRED_SIZE, 86,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(bombNumbers, javax.swing.GroupLayout.PREFERRED_SIZE, 86,
														javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addGroup(layout.createSequentialGroup().addGap(194, 194, 194).addComponent(startGame)))
						.addContainerGap(68, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(109, 109, 109)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel1).addComponent(bombNumbers, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(42, 42, 42)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabel2).addComponent(gridNumbers, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(60, 60, 60).addComponent(startGame, javax.swing.GroupLayout.PREFERRED_SIZE, 44,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(172, Short.MAX_VALUE)));

		pack();
	}

	private void startGameActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_startGameActionPerformed
		Boolean flag=true;
		String bombNums=bombNumbers.getText();
		String gridNums=gridNumbers.getText();		
		if(!(bombNums.matches("\\d+") && gridNums.matches("\\d+"))) {
			JOptionPane.showConfirmDialog(null, "sorry~~,您输入的数据有误", "提示信息", JOptionPane.YES_NO_OPTION);
			bombNumbers.setText("");
			gridNumbers.setText("");
			bombNumbers.requestFocus();
			flag=false;
		}
			
		
		int numbers = Integer.valueOf(bombNumbers.getText());
		int gridNumber = Integer.valueOf(gridNumbers.getText());
		if(numbers <5 || gridNumber>15 || gridNumber<5 || numbers>15) {
			JOptionPane.showConfirmDialog(null, "sorry~~,您输入的数据有误，请重新输入", "提示信息", JOptionPane.YES_NO_OPTION);
			bombNumbers.setText("");
			gridNumbers.setText("");
			bombNumbers.requestFocus();
			flag=false;
		}
		if(flag) {
			this.dispose();
			new game(numbers, gridNumber).setVisible(true);
		}
		
	}

	public static void main(String args[]) {

		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new firstFrame().setVisible(true);
			}
		});
	}

	private javax.swing.JTextField bombNumbers;
	private javax.swing.JTextField gridNumbers;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JButton startGame;
}

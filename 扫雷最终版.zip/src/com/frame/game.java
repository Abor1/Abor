/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.frame;

import com.UIutil.UIUtil;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author Abor
 */
public class game extends javax.swing.JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int bombNumbers;// 雷的个数
	private int gridNumber;// 每行每列格子个数
	private JButton[][] buttons;// 格子按钮的数组
	private ImageIcon[] numIcons;// 需要用到的图标资源
	private int[][] bombSign;// 雷的标记数组
	private HashSet<Integer> bombSet;// 雷的标记列表
	private boolean[][] visited;
	private ImageIcon bombBurst;// 雷爆炸图标
	private ImageIcon flag;// 旗帜图标
	private ImageIcon basicIcon;// 未点击时的图标
	private long startTime;// 游戏开始时间
	private long endTime;// 游戏结束时间

	private static final int BOMB_MARK = -1;
	private static final int FLAG_MARK = -2;

	public game(int bombNumbers, int gridNumber) {
		this.bombNumbers = bombNumbers;
		this.gridNumber = gridNumber;
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		init();
		this.setVisible(true);

	}

	private void init() {
		this.setTitle(bombNumbers + "个雷 " + gridNumber + "*" + gridNumber + "布局");// 设置标题
		this.setBounds(0, 0, gridNumber * 60, gridNumber * 60);
		this.setLayout(new GridLayout(gridNumber, gridNumber));
		UIUtil.setIcon(this);// 设置图标
		UIUtil.setFrameCenter(this);// 窗口居中

		getImage();
		writeMap();
		newBomb();

		startTime = System.currentTimeMillis();
	}

	// 切换窗口
	private void changeFrame() {
		this.dispose();
		new firstFrame().setVisible(true);
	}

	// 检查游戏是否成功
	private boolean checkSuccess() {
		boolean flag = true;
		// 比较所有旗帜和炸弹的bombsign
		for (int i : bombSet) {
			int a = (int) (i / gridNumber);
			int b = i - a * gridNumber;
			if (bombSign[a][b] != FLAG_MARK)
				flag = false;
		}
		return flag;
	}

	// 生成雷
	private void newBomb() {
		// 生成雷
		// 雷的标记数组与map对应,如果是雷就标记为-1，否则标记为0-8
		if (bombSign == null) {
			bombSign = new int[gridNumber][gridNumber];
		}
		if (visited == null) {
			visited = new boolean[gridNumber][gridNumber];
		}
		// 雷的标记列表，不允许重复，采用hashset列表
		bombSet = new HashSet<>();
		int bomb;
		while (bombSet.size() < bombNumbers) {
			bomb = (int) (Math.random() * gridNumber * gridNumber);
			if (bombSet.add(bomb)) {
				int x = (int) (bomb / gridNumber);
				int y = bomb - x * gridNumber;
				bombSign[x][y] = BOMB_MARK;
			}
		}
		for (int i = 0; i < gridNumber; i++)
			for (int j = 0; j < gridNumber; j++) {
				// 将所有的visited置为false
				visited[i][j] = false;
				int count = 0;// 雷的计数器
				if (bombSign[i][j] == BOMB_MARK)// 如果本身是雷的话，直接跳过
					continue;
				// 对本身的周围8个格子进行判断，并对计数器进行操作
				for (int m = -1; m <= 1; m++)
					for (int n = -1; n <= 1; n++) {
						// 跳过边界之外的点
						if (m + i < 0 || m + i >= gridNumber || n + j < 0 || n + j >= gridNumber)
							continue;
						// 跳过本身
						if (m == 0 && n == 0)
							continue;
						if (bombSign[m + i][n + j] == BOMB_MARK)
							count++;
					}
				// 对本身格子进行赋值
				bombSign[i][j] = count;
			}

	}

	// 设置自身图标
	private void setMyIcon(int x, int y) {
		if (bombSign[x][y] == BOMB_MARK)
			buttons[x][y].setIcon(bombBurst);
		else if (bombSign[x][y] == FLAG_MARK) {
			buttons[x][y].setIcon(flag);
		} else {
			int num = bombSign[x][y];
			ImageIcon icon = numIcons[num];
			buttons[x][y].setIcon(icon);
			visited[x][y] = true;
		}
	}

	// 点击时做出的操作
	private void press(int x, int y) {
		if (bombSign[x][y] == BOMB_MARK) {
			setMyIcon(x, y);
			endTime = System.currentTimeMillis();
			// 显示所有炸弹
			for (int i : bombSet) {
				int a = (int) (i / gridNumber);
				int b = i - a * gridNumber;
				setMyIcon(a, b);
			}
			JOptionPane.showConfirmDialog(null, "sorry~~,您不小心点到炸弹啦\n耗时" + (endTime - startTime) / 1000 + "秒，将为您重新打开游戏",
					"提示信息", JOptionPane.YES_NO_OPTION);
			changeFrame();
			return;
		} else if (bombSign[x][y] != 0) {
			setMyIcon(x, y);
			return;
		} else if (bombSign[x][y] == 0) {
			setMyIcon(x, y);
			for (int m = -1; m <= 1; m++)
				for (int n = -1; n <= 1; n++) {
					if (m + x >= 0 && m + x < gridNumber && n + y >= 0 && n + y < gridNumber
							&& visited[m + x][n + y] == false)
						press(m + x, n + y);
				}
		}
	}

	// 获取图片资源
	private void getImage() {
		// 获取图标资源
		numIcons = new ImageIcon[9];
		for (int i = 0; i < 9; i++) {
			String imagePath = "src\\com\\resource\\" + i + ".jpg";
			numIcons[i] = new ImageIcon(imagePath);
		}
		new ImageIcon("src\\com\\resource\\bombFind.jpg");
		bombBurst = new ImageIcon("src\\com\\resource\\bombBurst.jpg");
		flag = new ImageIcon("src\\com\\resource\\flag.jpg");
		basicIcon = new ImageIcon("src\\com\\resource\\basicIcon.jpg");
	}

	// 绘制map
	private void writeMap() {
		// 绘制map
		buttons = new JButton[gridNumber][gridNumber];
		for (int i = 0; i < gridNumber; i++) {
			for (int j = 0; j < gridNumber; j++) {
				JButton jb = new JButton();
				// 设定透明效果
				jb.setOpaque(false);
				// 去掉背景点击效果
				jb.setContentAreaFilled(false);
				// 去掉聚焦线
				jb.setFocusPainted(false);
				// 去掉边框
				jb.setBorder(null);
				// 设置图标
				jb.setIcon(basicIcon);
				// 设置位置
				jb.setBounds(j * 50, i * 50, 50, 50);
				// 添加事件
				final int x = i;
				final int y = j;
				jb.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if (visited[x][y] == false)
							press(x, y);
					}
				});
				jb.addMouseListener(new MouseAdapter() {

					@Override
					public void mouseClicked(MouseEvent e) {
						if (e.isMetaDown() && visited[x][y] == false) {
							if (bombSign[x][y] == FLAG_MARK) {
								buttons[x][y].setIcon(basicIcon);
								// 如果本身是雷的话
								if (bombSet.contains(x * gridNumber + y)) {
									bombSign[x][y] = BOMB_MARK;
									return;
								}
								// 对本身的周围8个格子进行判断，并对计数器进行操作
								int count = 0;// 雷的计数器
								for (int m = -1; m <= 1; m++)
									for (int n = -1; n <= 1; n++) {
										// 跳过边界之外的点
										if (m + x < 0 || m + x >= gridNumber || n + y < 0 || n + y >= gridNumber)
											continue;
										// 跳过本身
										if (m == 0 && n == 0)
											continue;
										if (bombSign[m + x][n + y] == BOMB_MARK)
											count++;
									}
								// 对本身格子进行赋值
								bombSign[x][y] = count;
								return;

							}

							bombSign[x][y] = FLAG_MARK;
							setMyIcon(x, y);
							// 检验游戏是否成功
							if (checkSuccess()) {
								endTime = System.currentTimeMillis();
								// 显示所有炸弹
								for (int i : bombSet) {
									int a = (int) (i / gridNumber);
									int b = i - a * gridNumber;
									buttons[a][b].setIcon(new ImageIcon("src\\com\\resource\\bombFind.jpg"));
								}
								JOptionPane.showConfirmDialog(null, "Congratulations!!!,您找出了所有地雷\n耗时"
										+ (endTime - startTime) / 1000 + "秒，将为您重新打开游戏", "提示信息",
										JOptionPane.YES_NO_OPTION);
								changeFrame();
							}
						}
					}

				});
				// 添加按钮
				buttons[i][j] = jb;
				this.add(buttons[i][j]);

			}
		}
	}

}
